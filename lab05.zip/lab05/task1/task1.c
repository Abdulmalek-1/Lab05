#include <stdio.h>

int main(){
    int N;
    int asterisks = 1;    
    printf("N = ");
    scanf("%d" , &N);
    int i = 1;
    while(i <= N){
        int j = 1;
        while(j <= N - i){
            printf(" ");
            j++;
        }
        int k = 1;
        while(k <= asterisks){
            printf("*");
            k++;
        }
        asterisks++;
        printf("\n");
        i++;
    }

    return 0;
}
