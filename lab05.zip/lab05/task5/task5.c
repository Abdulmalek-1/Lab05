#include <stdlib.h>
#include <time.h>
#include <stdio.h>
int main(){
    srand(time(NULL));
    int RGB[10][10][3];
    //RED
    for(int i = 0; i < 10; i++){
        for(int j = 0; j < 10; j++){
            RGB[i][j][0] = (rand() % (255 - 0 + 1) + 0);
        }
    }
    //GREEN
    for(int i = 0; i < 10; i++){
        for(int j = 0; j < 10; j++){
            RGB[i][j][1] = (rand() % (255 - 0 + 1) + 0);
        }
    }
    //BLUE
    for(int i = 0; i < 10; i++){
        for(int j = 0; j < 10; j++){
            RGB[i][j][2] = (rand() % (255 - 0 + 1) + 0);
        }
    }
    float Grayscale[10][10];
    for(int i = 0; i < 10; i++){
        for(int j = 0; j < 10; j++){
            Grayscale[i][j] = 0.299 * RGB[i][j][0] + 0.587 *
            RGB[i][j][1] + 0.114 * RGB[i][j][2];
        }
    }
    
    printf("RGB:\n\n");
    for(int i = 0; i < 10; i++){
        for(int j = 0; j < 10; j++){
            printf("(");
            for(int k = 0; k < 3; k++){
                printf("%d ", RGB[i][j][k]);
            }
            printf(")   ");
        }
        printf("\n");
    }
    printf("\nGrayscale:\n\n");
    for(int i = 0; i < 10; i++){
        for(int j = 0; j < 10; j++){
            printf("%.2f  ", Grayscale[i][j]);
        }
        printf("\n");
    }
    return 0;
}
