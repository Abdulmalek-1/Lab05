#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(){
    srand(time(NULL));
    int grid[10][10];
    printf("The 2D grid: \n");
    for(int i = 0; i < 10; i++){
        for(int j = 0; j < 10; j++){
            printf("\t(%d,%d)", i,j);
        }
        printf("\n");
    }
    printf("Generating hidden treasure (xt,yt)...\n");
    // to generate a random number from min <= x <= max 
    // rand() % (max - min + 1) + min
    int xt = ( rand() % (9 - 0 + 1) + 0 );
    int yt = ( rand() % (9 - 0 + 1) + 0 );
    for(int i = 0; i < 10; i++){
        for(int j = 0; j < 10; j++){
            if(i == xt && j == yt){
                printf("Hurrah!, I have found the hidden treasure\n");
                printf("It was here: (%d,%d)\n", i,j);
            }
        }
    }  
    
    return 0;
}
