#include <stdio.h>


int main(){
    int cities[10];
    printf("Enter the population of 10 cities:\n");
    for(int i = 0; i < 10; i++){
        printf("Enter the population of city %d:", i+1);
        scanf("%d", &cities[i]);
    }
    int max, min;
    float sum = 0;
    max  = min = cities[0];
    printf("\n");
    for(int i = 9; i > -1; i--){
        if(max < cities[i]){
            max = cities[i];
        }
        if(min > cities[i]){
            min = cities[i];
        }
        printf("The population of city %d: %d\n", i+1, cities[i]);
        sum += cities[i];
    }   
    printf("Maximum population: %d\n", max);
    printf("Minimum population: %d\n", min);
    printf("Average population: %.2f\n", (sum / 10) );
    return 0;
}
