#include <stdio.h>

int main(){
    int minute;    
    printf("Enter the number of minutes: ");
    scanf("%d" , &minute);
    for(int i = 0; i < minute; i++){
        for(int j = 0; j < 60; j++){
            printf("%d:%d\n",i,j);
        }
    }

    return 0;
}
